function Catalog(products) {
    var items = products || [];


    this.indexOf = function (product) {
        var result = -1;
        for (var i = 0; i < items.length; i++) {
            if (items[i].id === product.id) {
                result = i;
            }
        }
        return result;
    }


    this.getProduct = function (productID) {
        var result = null;

        for (var i = 0; i < items.length; i++) {
            if (productID == items[i].id) {
                result = items[i];
            }
        }
        return result;
    }

    this.getItems = function () {
        var result;

        result = items.map(x => x);
        // Itt implement�ld a keres�st

        return result;
    }
}