var currentProductID;
var catalog;
var order;

window.addEventListener('load', window_LoadHandler);

function initializeComponents() {
    var nodesA = document.querySelectorAll('A[data-action]');

    for (var i = 0; i < nodesA.length; i++) {
        nodesA[i].addEventListener('click', Application.changeView);
    }
    catalog = new Catalog(beers);
    order = new Order();
}
function window_LoadHandler() {
    initializeComponents();
    Application.changeView('ProductList');
}
